# FoodAlert
Shows a persistent readout with the amount of food you currently have in storage, and an estimate of how long stocks will last.

Ludeon: https://ludeon.com/forums/index.php?topic=35832.0  
Steam: https://steamcommunity.com/sharedfiles/filedetails/?id=1114619043  
Github: https://github.com/Mehni/FoodAlert
